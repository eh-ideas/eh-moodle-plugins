<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Privacy provider for block_academichistory.
 *
 * This plugin does not store any personal data of its own.
 * It only reads data managed by Moodle core (course_completions, grade_grades)
 * and optionally by the customcert plugin (customcert_issues).
 *
 * @package   block_academichistory
 * @copyright 2024 Your Name <your@email.com>
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_academichistory\privacy;

use core_privacy\local\metadata\null_provider;

/**
 * Privacy provider implementation.
 *
 * Implements null_provider because this plugin stores no personal data itself.
 */
class provider implements null_provider {

    /**
     * Returns the reason why this plugin stores no personal data.
     *
     * @return string The language string key pointing to the privacy:metadata string.
     */
    public static function get_reason(): string {
        return 'privacy:metadata';
    }
}
