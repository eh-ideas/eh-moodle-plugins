<?php

global $DB;
require_once('../../config.php');
require_login();

// Obtener el ID de la ruta a eliminar
$id = required_param('id', PARAM_INT);

// Verificar permisos
$context = context_system::instance();
require_capability('moodle/site:manageblocks', $context);

// Comprobar si la ruta de aprendizaje existe
$learningpath = $DB->get_record('block_simple_learning_path', ['id' => $id], '*', MUST_EXIST);

// Eliminar las relaciones entre la ruta y los cursos asociados
$DB->delete_records('block_simple_learning_path_courses', ['learningpathid' => $id]);

// Eliminar la ruta de aprendizaje
$DB->delete_records('block_simple_learning_path', ['id' => $id]);

// Redirigir de vuelta a la página principal después de eliminar
redirect(new moodle_url('/blocks/simple_learning_path/index.php'), 'Ruta de aprendizaje eliminada exitosamente');