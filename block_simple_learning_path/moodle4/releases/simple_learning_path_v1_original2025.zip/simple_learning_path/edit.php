<?php

require_once('../../config.php');
require_login();

$id = optional_param('id', 0, PARAM_INT);
$context = context_system::instance();
require_capability('moodle/site:manageblocks', $context);

$PAGE->set_url(new moodle_url('/blocks/simple_learning_path/edit.php', ['id' => $id]));
$PAGE->set_context($context);
$PAGE->set_title($id ? 'Editar Ruta de Aprendizaje' : 'Crear Nueva Ruta de Aprendizaje');
$PAGE->set_heading($id ? 'Editar Ruta de Aprendizaje' : 'Crear Nueva Ruta de Aprendizaje');

$uniqid = uniqid('category-course-');

$template_data = [
    'id' => $id,
    'is_editing' => $id > 0,
    'action_url' => new moodle_url('/blocks/simple_learning_path/edit.php', ['id' => $id]),
    'cancel_url' => new moodle_url('/blocks/simple_learning_path/index.php'),
    'sesskey' => sesskey(),
    'nombre_ruta' => '',
    'url' => '#',
    'criterio' => '',
    'cohortid' => 0,
    'categories' => [],
    'courses_by_category' => [],
    'selected_courses' => [],
    'cohorts' => [],
    'uniqid' => $uniqid
];

// Cargar datos si se está editando
if ($id) {
    $learningpath = $DB->get_record('block_simple_learning_path', ['id' => $id], '*', MUST_EXIST);
    $template_data['nombre_ruta'] = $learningpath->nombre_ruta;
    $template_data['url'] = $learningpath->url;
    $template_data['criterio'] = $learningpath->criterio;
    $template_data['cohortid'] = $learningpath->cohortid;

    // Obtener los cursos asociados con sus nombres y categorías
    $associated_courses = $DB->get_records_sql('
        SELECT c.id, c.fullname, cc.name AS categoryname
        FROM {block_simple_learning_path_courses} lpc
        JOIN {course} c ON lpc.courseid = c.id
        JOIN {course_categories} cc ON c.category = cc.id
        WHERE lpc.learningpathid = ?', [$id]);

    $template_data['selected_courses'] = [];
    foreach ($associated_courses as $course) {
        $template_data['selected_courses'][] = [
            'id' => $course->id,
            'fullname' => $course->fullname,
            'categoryname' => $course->categoryname,
        ];
    }
}

// Obtener categorías y cursos para la plantilla
$categories = $DB->get_records_menu('course_categories', null, '', 'id, name');
$courses = $DB->get_records('course', null, '', 'id, fullname, category');

// Crear un mapa de IDs de categorías a nombres de categorías
$category_names = [];
foreach ($categories as $cat_id => $cat_name) {
    $category_names[$cat_id] = $cat_name;
    $template_data['categories'][] = [
        'id' => $cat_id,
        'name' => $cat_name,
    ];
}

// Inicializar 'courses_by_category'
foreach ($courses as $course) {
    // Obtener el nombre de la categoría
    $category_name = isset($category_names[$course->category]) ? $category_names[$course->category] : '';

    $template_data['courses_by_category'][$course->category][] = [
        'id' => $course->id,
        'fullname' => $course->fullname,
        'categoryname' => $category_name,
    ];
}

// Obtener las cohortes disponibles
$cohorts = $DB->get_records('cohort', null, 'name ASC', 'id, name');
foreach ($cohorts as $cohort) {
    $template_data['cohorts'][] = [
        'id' => $cohort->id,
        'name' => $cohort->name,
        'selected' => ($cohort->id == $template_data['cohortid'])
    ];
}

$template_data['courses_by_category_json'] = json_encode($template_data['courses_by_category'], JSON_UNESCAPED_UNICODE);

// Marcar el criterio seleccionado
$template_data['criterio_cursos_checked'] = ($template_data['criterio'] === 'cursos') ? 'checked' : '';
$template_data['criterio_curso_checked'] = ($template_data['criterio'] === 'curso') ? 'checked' : '';
$template_data['criterio_cohorte_checked'] = ($template_data['criterio'] === 'cohorte') ? 'checked' : '';

// Procesar el formulario enviado
$data = data_submitted();
if ($data && confirm_sesskey()) {
    // Validar el campo URL: debe ser '#' o una URL válida
    if ($data->url !== '#') {
        if (!filter_var($data->url, FILTER_VALIDATE_URL)) {
            throw new moodle_exception('invalidurl', 'block_simple_learning_path', '', $data->url);
        }
    }

    // Validar el criterio
    $valid_criteria = ['cursos', 'curso', 'cohorte'];
    if (!in_array($data->criterio, $valid_criteria)) {
        throw new moodle_exception('invalidcriterio', 'block_simple_learning_path');
    }

    // Manejar 'cohortid' según el criterio
    $cohortid = null;
    if ($data->criterio === 'cohorte') {
        if (empty($data->cohortid)) {
            throw new moodle_exception('nocohortid', 'block_simple_learning_path');
        }
        $cohortid = $data->cohortid;
    }

    if (!empty($data->id)) {
        // EDITAR la ruta de aprendizaje existente
        $learningpath = $DB->get_record('block_simple_learning_path', ['id' => $data->id], '*', MUST_EXIST);

        // Actualizar los datos
        $learningpath->nombre_ruta = $data->nombre_ruta;
        $learningpath->url = $data->url;
        $learningpath->criterio = $data->criterio;
        $learningpath->cohortid = $cohortid;
        $learningpath->timemodified = time();
        $DB->update_record('block_simple_learning_path', $learningpath);

        // Actualizar las relaciones con los cursos
        $DB->delete_records('block_simple_learning_path_courses', ['learningpathid' => $data->id]);
        if (!empty($data->category_course)) {
            foreach ($data->category_course as $courseid_associated) {
                $DB->insert_record('block_simple_learning_path_courses', [
                    'learningpathid' => $data->id,
                    'courseid' => $courseid_associated
                ]);
            }
        }

        // Redirigir después de guardar
        redirect(new moodle_url('/blocks/simple_learning_path/index.php'), get_string('changes_saved', 'block_simple_learning_path'));
    } else {
        // CREAR una nueva ruta de aprendizaje
        $newlearningpath = new stdClass();
        $newlearningpath->nombre_ruta = $data->nombre_ruta;
        $newlearningpath->url = $data->url;
        $newlearningpath->criterio = $data->criterio;
        $newlearningpath->cohortid = $cohortid;
        $newlearningpath->timecreated = time();
        $newlearningpath->timemodified = time();
        $learningpathid = $DB->insert_record('block_simple_learning_path', $newlearningpath);

        // Guardar la relación con los cursos seleccionados
        if (!empty($data->category_course)) {
            foreach ($data->category_course as $courseid_associated) {
                $DB->insert_record('block_simple_learning_path_courses', [
                    'learningpathid' => $learningpathid,
                    'courseid' => $courseid_associated
                ]);
            }
        }

        // Redirigir después de crear
        redirect(new moodle_url('/blocks/simple_learning_path/index.php'), get_string('new_learning_path_created', 'block_simple_learning_path'));
    }
}

// Renderizar la vista del formulario
echo $OUTPUT->header();
echo $OUTPUT->render_from_template('block_simple_learning_path/edit', $template_data);
echo $OUTPUT->footer();