// Archivo: amd/src/filtercourses.js
export const init = (allCourses) => {
  // Verificar si allCourses está correctamente definido
  if (!allCourses || Object.keys(allCourses).length === 0) {
    // Console.error('No se encontraron cursos o allCourses no está definido.');
    return;
  }

  // Definir la función para filtrar los cursos
  window.filterCoursesByCategory = function() {
    const selectedCategory = document.getElementById('id_categoryid').value;  // Obtener la categoría seleccionada
    const courseSelect = document.getElementById('id_courseids');
    courseSelect.innerHTML = '';  // Limpiar los cursos actuales

    // Filtrar y mostrar los cursos correspondientes a la categoría seleccionada
    Object.keys(allCourses).forEach((courseid) => {
      const course = allCourses[courseid];
      if (course.category == selectedCategory) {
        const option = new Option(course.fullname, courseid);
        courseSelect.appendChild(option);
      }
    });
  };
};