/**
 * @module block_simple_learning_path/edit_module
 */
define(['jquery', 'core/str', 'core/log'], function($, Str, Log) {
  'use strict';

  /**
   * Initialize the edit module.
   *
   * @param {Object} params - Parameters passed from PHP.
   */
  function init(params) {
    const uniqid = params.uniqid;
    const courseid = params.courseid;
    const selectedCourse = params.selected_course;
    const coursesByCategory = params.courses_by_category;
    const existingCourseId = courseid;

    // Functions can be declared here

    /**
     * Update the course select options based on selected category and search input.
     */
    function updateCourseSelect() {
      // Access DOM elements inside the function
      const categorySelect = document.getElementById(`${uniqid}-category-select`);
      const courseSelect = document.getElementById(`${uniqid}-course-select`);
      const courseSearch = document.getElementById(`${uniqid}-course-search`);
      const addCourseButton = document.getElementById(`${uniqid}-add-course`);
      const resetSearchButton = document.getElementById(`${uniqid}-reset-search`);

      const selectedCategory = categorySelect.value;
      const searchQuery = courseSearch.value.toLowerCase();
      courseSelect.innerHTML = '';

      let hasOptions = false;

      if (coursesByCategory[selectedCategory]) {
        coursesByCategory[selectedCategory].forEach(course => {
          // Do not show courses that are already added
          if (!isCourseAdded(course.id) && course.fullname.toLowerCase().includes(searchQuery)) {
            const option = document.createElement('option');
            option.value = course.id;
            option.textContent = `${course.id} - ${course.categoryname} - ${course.fullname}`;
            courseSelect.appendChild(option);
            hasOptions = true;
          }
        });
      }

      // Disable the "Add Course" button by default
      addCourseButton.disabled = true;

      if (hasOptions) {
        // Do not auto-select any course
        courseSelect.selectedIndex = -1;
        // "Add Course" button will be enabled when a course is selected
      } else {
        // No courses available
        addCourseButton.disabled = true;
      }

      // Enable or disable the "Reset Search" button based on search input
      resetSearchButton.disabled = courseSearch.value.trim() === '';
    }

    // Other functions (updateCourseIdSelect, addCourseToList, removeCourseFromList, isCourseAdded)
    // Move the DOM element references inside these functions as well

    // Initialize on page load
    $(document).ready(function() {
      // Access DOM elements here
      const categorySelect = document.getElementById(`${uniqid}-category-select`);
      const courseSelect = document.getElementById(`${uniqid}-course-select`);
      const courseSearch = document.getElementById(`${uniqid}-course-search`);
      const addCourseButton = document.getElementById(`${uniqid}-add-course`);
      const resetSearchButton = document.getElementById(`${uniqid}-reset-search`);
      const addedCoursesList = document.getElementById(`${uniqid}-added-courses`);
      const criterioRadios = document.getElementsByName('criterio');
      const courseSelectContainer = document.getElementById('course-select-container');
      const cohortSelectContainer = document.getElementById('cohort-select-container');

      // Now that elements are available, set up event listeners

      // Event Listeners
      categorySelect.addEventListener('change', function() {
        courseSearch.value = ''; // Clear search when category changes
        updateCourseSelect();
      });

      courseSearch.addEventListener('input', function() {
        updateCourseSelect();
      });

      courseSelect.addEventListener('change', function() {
        // Enable or disable the "Add Course" button based on selection
        addCourseButton.disabled = courseSelect.selectedIndex === -1;
      });

      addCourseButton.addEventListener('click', function() {
        const selectedOption = courseSelect.options[courseSelect.selectedIndex];
        if (selectedOption && selectedOption.value) {
          const courseId = selectedOption.value;
          const courseInfo = selectedOption.textContent;

          // Split text to get categoryName and courseName
          const [, categoryName, ...courseNameParts] = courseInfo.split(' - ');
          const courseName = courseNameParts.join(' - ');

          addCourseToList(courseId, categoryName, courseName);
          courseSearch.value = ''; // Reset search field
          updateCourseSelect();
        }
      });

      resetSearchButton.addEventListener('click', function() {
        courseSearch.value = '';
        updateCourseSelect();
      });

      addedCoursesList.addEventListener('click', function(event) {
        const target = event.target;
        let courseId;
        if (target.matches('[data-remove-course]')) {
          courseId = target.getAttribute('data-remove-course');
        } else {
          const removeButton = target.closest('[data-remove-course]');
          if (removeButton) {
            courseId = removeButton.getAttribute('data-remove-course');
          }
        }
        if (courseId) {
          removeCourseFromList(courseId);
          updateCourseSelect();
        }
      });

      // Handle visibility of fields based on selected criterion

      /**
       * Update the visibility of fields based on the selected criterion.
       */
      function updateCriterioFields() {
        let selectedCriterio = document.querySelector('input[name="criterio"]:checked').value;
        courseSelectContainer.style.display = 'none';
        cohortSelectContainer.style.display = 'none';

        if (selectedCriterio === 'curso') {
          courseSelectContainer.style.display = 'block';
          updateCourseIdSelect(); // Update the course selector
        } else if (selectedCriterio === 'cohorte') {
          cohortSelectContainer.style.display = 'block';
        }
      }

      criterioRadios.forEach(radio => {
        radio.addEventListener('change', updateCriterioFields);
      });

      // Initialize functions
      updateCourseSelect();
      updateCriterioFields();
      // Ensure updateCourseIdSelect() runs after courses are rendered
      setTimeout(function() {
        updateCourseIdSelect();
      }, 0);

      // Log that the module has been initialized
      Log.debug('block_simple_learning_path/edit_module: initialized');
    });

    /**
     * Update the course ID select for criterion 'curso'.
     */
    function updateCourseIdSelect() {
      const courseIdSelect = document.getElementById('courseid');
      const addedCoursesList = document.getElementById(`${uniqid}-added-courses`);
      courseIdSelect.innerHTML = ''; // Clear options

      // Add default option
      const defaultOption = document.createElement('option');
      defaultOption.value = '';
      defaultOption.textContent = M.util.get_string('select_course_option', 'block_simple_learning_path');
      courseIdSelect.appendChild(defaultOption);

      let coursesToAdd = [];

      // Get courses from added courses list
      const addedCourses = addedCoursesList.querySelectorAll('li[data-course-id]');

      if (addedCourses.length > 0) {
        addedCourses.forEach(courseItem => {
          const courseId = courseItem.dataset.courseId;
          const courseText = courseItem.querySelector('span').textContent;

          coursesToAdd.push({
            id: courseId,
            text: courseText
          });
        });
      } else if (selectedCourse && selectedCourse.id) {
        // If no courses added but a selected course exists, add it
        const courseText = `${selectedCourse.id} - ${selectedCourse.categoryname} - ${selectedCourse.fullname}`;
        coursesToAdd.push({
          id: selectedCourse.id,
          text: courseText
        });
      }

      coursesToAdd.forEach(course => {
        const option = document.createElement('option');
        option.value = course.id;
        option.textContent = course.text;

        // Mark as selected if it matches the existingCourseId
        if (existingCourseId && course.id == existingCourseId) {
          option.selected = true;
        }

        courseIdSelect.appendChild(option);
      });

      // Disable the selector if no courses
      courseIdSelect.disabled = coursesToAdd.length === 0;
    }

    /**
     * Add a course to the added courses list.
     *
     * @param {number} courseId - The ID of the course to add.
     * @param {string} categoryName - The name of the course's category.
     * @param {string} courseName - The name of the course.
     */
    function addCourseToList(courseId, categoryName, courseName) {
      const addedCoursesList = document.getElementById(`${uniqid}-added-courses`);
      // Avoid duplicates
      if (isCourseAdded(courseId)) {
        return;
      }

      const listItem = document.createElement('li');
      listItem.className = 'list-group-item d-flex justify-content-between align-items-center';
      listItem.dataset.courseId = courseId;

      const courseInfo = `${courseId} - ${categoryName} - ${courseName}`;
      const courseNameSpan = document.createElement('span');
      courseNameSpan.textContent = courseInfo;

      const removeButton = document.createElement('button');
      removeButton.type = 'button';
      removeButton.className = 'btn btn-danger btn-sm';
      removeButton.setAttribute('data-remove-course', courseId);
      removeButton.innerHTML = '<i class="icon fa fa-trash fa-fw"></i>';

      listItem.appendChild(courseNameSpan);
      listItem.appendChild(removeButton);

      // Add a hidden input to submit the selected course data
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = 'category_course[]';
      input.value = courseId;
      listItem.appendChild(input);

      addedCoursesList.appendChild(listItem);

      // Update the course ID select
      updateCourseIdSelect();
    }

    /**
     * Remove a course from the added courses list.
     *
     * @param {number} courseId - The ID of the course to remove.
     */
    function removeCourseFromList(courseId) {
      const addedCoursesList = document.getElementById(`${uniqid}-added-courses`);
      const courseItem = addedCoursesList.querySelector(`[data-course-id="${courseId}"]`);
      if (courseItem) {
        courseItem.remove();
      }

      // Update the course ID select
      updateCourseIdSelect();
    }

    /**
     * Check if a course is already added to the list.
     *
     * @param {number} courseId - The ID of the course to check.
     * @returns {boolean} - True if the course is added, false otherwise.
     */
    function isCourseAdded(courseId) {
      const addedCoursesList = document.getElementById(`${uniqid}-added-courses`);
      return addedCoursesList.querySelector(`[data-course-id="${courseId}"]`) !== null;
    }
  }

  return {
    init: init
  };
});