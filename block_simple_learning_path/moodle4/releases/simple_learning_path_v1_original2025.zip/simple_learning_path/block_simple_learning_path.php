<?php
defined('MOODLE_INTERNAL') || die();

global $CFG;
require_once($CFG->libdir . '/filelib.php');

class block_simple_learning_path extends block_base {

    function has_config() {
        return true;
    }

    public function applicable_formats() {
        return [
            'all' => true,
        ];
    }

    public function init() {
        $this->title = get_string('simple_learning_path', 'block_simple_learning_path');
    }

    public function get_content() {
        if ($this->content !== null) {
            return $this->content;
        }

        global $USER, $DB;

        $uniqueid = 'slp' . uniqid();
        $rutas = $this->get_learning_paths();
        $mis_cursos = $this->get_courses_progress();

        echo "<script>console.log('Total rutas encontradas: " . count($rutas) . "');</script>";

        $data = [
            'uniqueid' => $uniqueid,
            'routes' => []
        ];

        $isFirstRoute = true;
        $routes_found = false;

        foreach ($rutas as $ruta) {
            echo "<script>console.log('Evaluando ruta: " . $ruta['nombre'] . "');</script>";

            if (!$this->user_meets_criteria($ruta, $mis_cursos)) {
                echo "<script>console.log('Usuario NO cumple criterio para la ruta: " . $ruta['nombre'] . "');</script>";
                continue;
            }

            echo "<script>console.log('Usuario cumple criterio para la ruta: " . $ruta['nombre'] . "');</script>";
            $routes_found = true;

            $rutaCursos = $ruta['cursos'];
            $coursesData = [];
            $totalProgress = 0;
            $numCoursesWithProgress = 0;

            foreach ($rutaCursos as $curso) {
                $courseDetails = $this->get_course_details($curso['shortname']);
                $courseProgressData = $mis_cursos[$curso['shortname']] ?? null;

                $courseProgress = $courseProgressData['progress'] ?? 0;
                $isCompleted = $courseProgressData['is_completed'] ?? false;
                $isInProgress = !$isCompleted && $courseProgress > 0;
                $isPending = !$isCompleted && !$isInProgress;

                $coursesData[] = [
                    'courseName' => $courseDetails['fullname'],
                    'courseDescription' => $courseDetails['summary'],
                    'courseEndDate' => $isCompleted ? date('Y-m-d', $courseProgressData['course_completion_time']) : get_string('no_date', 'block_simple_learning_path'),
                    'courseProgress' => $courseProgress,
                    'isCompleted' => $isCompleted,
                    'isInProgress' => $isInProgress,
                    'isPending' => $isPending,
                    'courseUrl' => (new moodle_url('/course/view.php', ['id' => $courseDetails['id']]))->out(),
                    'courseCoverUrl' => $courseDetails['cover_image_url']
                ];

                $totalProgress += $courseProgress;
                $numCoursesWithProgress++;
            }

            $routeProgress = $numCoursesWithProgress > 0 ? round($totalProgress / $numCoursesWithProgress) : 0;

            $data['routes'][] = [
                'id' => $ruta['id'],
                'routeName' => $ruta['nombre'],
                'coursesCompleted' => count(array_filter($coursesData, fn($course) => $course['isCompleted'])),
                'totalCourses' => $numCoursesWithProgress,
                'firstRoute' => $isFirstRoute,
                'ariaExpanded' => $isFirstRoute ? 'true' : 'false',
                'courses' => $coursesData,
                'routeProgress' => $routeProgress,
                'isCompleted' => ($routeProgress == 100)
            ];

            $isFirstRoute = false;
        }

        if (!$routes_found) {
            $this->content = new stdClass();
            $this->content->text = get_string('no_routes_available', 'block_simple_learning_path');
            return $this->content;
        }

        $renderer = $this->page->get_renderer('core');
        $this->content = new stdClass();
        $this->content->text = $renderer->render_from_template('block_simple_learning_path/rutas', $data);

        return $this->content;
    }

    private function user_meets_criteria($ruta, $mis_cursos) {
        global $USER, $DB;

        if (empty($ruta['criterio'])) {
            return true;
        }

        switch ($ruta['criterio']) {
            case 'cohorte':
                return $DB->record_exists('cohort_members', ['cohortid' => $ruta['cohortid'], 'userid' => $USER->id]);
            case 'cursos':
                foreach ($ruta['cursos'] as $curso) {
                    if (empty($mis_cursos[$curso['shortname']])) {
                        return false;
                    }
                }
                return true;
            case 'curso':
                foreach ($ruta['cursos'] as $curso) {
                    if (!empty($mis_cursos[$curso['shortname']])) {
                        return true;
                    }
                }
                return false;
            default:
                return false;
        }
    }

private function get_course_details($shortname){
        global $DB, $OUTPUT;

        $course = $DB->get_record('course', ['shortname' => $shortname], 'id, shortname, fullname, summary, summaryformat');

        if ($course) {
            $context = context_course::instance($course->id);
            $summary = file_rewrite_pluginfile_urls($course->summary, 'pluginfile.php', $context->id, 'course', 'summary', null);
            $summary = format_text($summary, $course->summaryformat, ['context' => $context]);

            $cover_image_url = \core_course\external\course_summary_exporter::get_course_image($course);

            if (!$cover_image_url) {
                $cover_image_url = $OUTPUT->image_url('placeholder', 'block_simple_learning_path')->out();
            }

            return [
                "id" => $course->id,
                "shortname" => $course->shortname,
                "fullname" => $course->fullname,
                "summary" => $summary,
                "cover_image_url" => $cover_image_url
            ];
        } else {
            return [
                "id" => null,
                "shortname" => $shortname,
                "fullname" => $shortname,
                "summary" => '',
                "cover_image_url" => $OUTPUT->image_url('placeholder', 'block_simple_learning_path')->out()
            ];
        }
    }

    private function get_courses_progress() {
        global $USER, $DB;

        // Filtrar cursos donde el usuario tiene el rol de estudiante
        $sql = "
        SELECT
            c.id AS courseid,
            c.shortname,
            c.fullname,
            COUNT(cmc.id) AS completed_activities,
            COUNT(cm.id) AS total_activities,
            cc.timecompleted AS course_completed_time
        FROM {course} c
        JOIN {enrol} e ON e.courseid = c.id
        JOIN {user_enrolments} ue ON ue.enrolid = e.id
        LEFT JOIN {course_modules} cm ON cm.course = c.id
        LEFT JOIN {course_modules_completion} cmc ON cmc.coursemoduleid = cm.id AND cmc.userid = ue.userid AND cmc.completionstate = 1
        LEFT JOIN {course_completions} cc ON cc.course = c.id AND cc.userid = ue.userid
        JOIN {context} ctx ON ctx.instanceid = c.id AND ctx.contextlevel = 50
        JOIN {role_assignments} ra ON ra.contextid = ctx.id AND ra.userid = ue.userid
        JOIN {role} r ON r.id = ra.roleid AND r.shortname = 'student'
        WHERE ue.userid = ?
        GROUP BY c.id, c.shortname, c.fullname, cc.timecompleted
    ";

        $params = [$USER->id];
        $records = $DB->get_records_sql($sql, $params);

        $courses_progress = [];

        foreach ($records as $record) {
            $activity_completion_rate = ($record->total_activities > 0)
                ? round(($record->completed_activities / $record->total_activities) * 100, 2)
                : 0;

            $is_course_completed = !is_null($record->course_completed_time);
            $course_progress = $is_course_completed ? 100 : $activity_completion_rate;

            $courses_progress[$record->shortname] = [
                'id' => $record->courseid,
                'shortname' => $record->shortname,
                'fullname' => $record->fullname,
                'activity_completion_rate' => $activity_completion_rate,
                'course_completion_time' => $record->course_completed_time,
                'progress' => $course_progress,
                'is_completed' => $is_course_completed
            ];
        }

        return $courses_progress;
    }

    function get_learning_paths() {
        global $DB;

        $learning_paths = $DB->get_records('block_simple_learning_path');
        $rutas = [];

        foreach ($learning_paths as $learning_path) {
            $cursos_asociados = $DB->get_records_sql('
                SELECT c.id, c.shortname
                FROM {block_simple_learning_path_courses} lpc
                JOIN {course} c ON lpc.courseid = c.id
                WHERE lpc.learningpathid = ?', [$learning_path->id]);

            $cursos = [];
            foreach ($cursos_asociados as $curso) {
                $cursos[] = [
                    'id' => $curso->id,
                    'shortname' => $curso->shortname
                ];
            }

            $rutas[] = [
                "id" => $learning_path->id,
                "nombre" => $learning_path->nombre_ruta,
                "url" => $learning_path->url,
                "criterio" => $learning_path->criterio,
                "cohortid" => $learning_path->cohortid,
                "cursos" => $cursos
            ];
        }

        return $rutas;
    }
}