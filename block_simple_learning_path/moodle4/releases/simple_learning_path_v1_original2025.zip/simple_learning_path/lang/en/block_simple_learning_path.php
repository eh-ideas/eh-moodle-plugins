<?php
$string['pluginname']   = 'Rutas de aprendizaje (simple)';
$string['headerconfig'] = 'Configuraciones';
$string['descconfig']   = 'Configuraciones generales para las rutas de aprendizaje.';

$string['labellearning_path_json_definition'] = 'Definición JSON';
$string['desclearning_path_json_definition']  = 'Definición de las rutas de aprendizaje disponibles en la plataforma, en formato JSON';

$string['defaulttitle'] = 'CURSOS Y RUTAS DE APRENDIZAJE';
$string['simple_learning_path'] = 'Rutas de aprendizaje';
$string['simple_learning_path:addinstance']   = 'Add a new simple LP block';
$string['simple_learning_path:myaddinstance'] = 'Add a new simple LP block to the My Moodle page';

$string['simple_learning_path:blocktitle']    = 'Título del bloque';
$string['simple_learning_path:rutajsonlabel'] = 'JSON de la Ruta';
$string['simple_learning_path:showmycourses'] = 'Mostrar mis cursos';
$string['simple_learning_path:showmylearningpaths'] = 'Mostrar mis rutas en proceso';

$string['nombre_ruta'] = 'Nombre de la Ruta';
$string['errornamerouteexists'] = 'Ya existe una ruta de aprendizaje con el nombre "{$a}". Por favor, elige un nombre diferente.';
$string['courses_help'] = 'Selecciona en orden los cursos que formarán parte de esta ruta de aprendizaje.';
$string['courses'] = 'Cursos';
$string['invalidurl'] = 'La URL proporcionada no es válida. Por favor, introduce una URL válida.';
$string['pluginmenu'] = 'Rutas de aprendizaje';

$string['url'] = 'URL de la ruta';
$string['url_help'] = 'Introduce la URL de la página web que contiene la información de la ruta de aprendizaje.';
$string['choosecategory'] = 'Selecciona una categoría';
$string['select_category'] = 'Selecciona una categoría';
$string['choosecourse'] = 'Selecciona un curso';
$string['add_course'] = 'Añadir curso';
$string['remove_course'] = 'Eliminar curso';
$string['select_course'] = 'Selecciona un curso';
$string['removecourse'] = 'Eliminar curso';
$string['search_course_placeholder'] = 'Buscar curso';
$string['searchcourse'] = 'Buscar';
$string['reset_search'] = 'Limpiar búsqueda';
$string['added_courses'] = 'Cursos agregados';
$string['general_information'] = 'Información general';
$string['course_selection'] = 'Selección de cursos';
$string['display_criteria'] = 'Criterio de visualización';
$string['select_criteria'] = 'Seleccione el criterio por el cual se mostrará esta ruta al usuario:';
$string['criteria_option_cursos'] = 'Estar matriculado en todos los cursos de la ruta';
$string['criteria_option_curso'] = 'Estar matriculado en un curso de la ruta';
$string['criteria_option_cohorte'] = 'Pertenecer a una cohorte específica';
$string['select_course_for_criteria'] = 'Seleccione un curso para el criterio';
$string['select_course_option'] = 'Seleccione un curso';
$string['select_cohort'] = 'Seleccione una cohorte';
$string['select_cohort_option'] = 'Seleccione una cohorte';
$string['invalidcriterio'] = 'Criterio inválido seleccionado';
$string['changes_saved'] = 'Cambios guardados';
$string['new_learning_path_created'] = 'Nueva ruta de aprendizaje creada';

$string['no_routes_available'] = 'No hay rutas de aprendizaje disponibles para usted en este momento.';




