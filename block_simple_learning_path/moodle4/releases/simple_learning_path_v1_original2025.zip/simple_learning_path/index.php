<?php

require_once('../../config.php');
require_login();

// Definir el contexto y la URL de la página actual
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/blocks/simple_learning_path/index.php'));

// Título y encabezado de la página
$PAGE->set_title('Configuración del Bloque Learning Path');
$PAGE->set_heading('Configuración del Bloque Learning Path');

// Renderizar la cabecera de Moodle
echo $OUTPUT->header();

// Definir la URL para crear una nueva ruta
$createurl = new moodle_url('/blocks/simple_learning_path/edit.php');

// Obtener las rutas de aprendizaje desde la base de datos
$learningpaths = $DB->get_records('block_simple_learning_path');

// Preparar los datos para la plantilla Mustache
$template_data = [
    'createurl' => $createurl->out(), // La URL de creación siempre disponible
    'learning_paths' => []
];

// Procesar las rutas de aprendizaje para la plantilla
foreach ($learningpaths as $learningpath) {
    $editurl = new moodle_url('/blocks/simple_learning_path/edit.php', ['id' => $learningpath->id]);
    $deleteurl = new moodle_url('/blocks/simple_learning_path/delete.php', ['id' => $learningpath->id, 'sesskey' => sesskey()]);

    // Obtener los cursos asociados a esta ruta desde la tabla intermedia
    $courses = $DB->get_records_sql('
        SELECT c.id, c.fullname
        FROM {block_simple_learning_path_courses} lpc
        JOIN {course} c ON lpc.courseid = c.id
        WHERE lpc.learningpathid = ?', [$learningpath->id]);

    // Convertir los cursos en un array
    $cursos = [];
    foreach ($courses as $course) {
        $cursos[] = ['fullname' => $course->fullname];
    }

    // Convertir el criterio a texto legible
    switch ($learningpath->criterio) {
        case 'cursos':
            $criterio_texto = 'Estar matriculado en todos los cursos de la ruta';
            break;
        case 'curso':
            $criterio_texto = 'Estar matriculado en cualquier curso de la ruta';
            break;
        case 'cohorte':
            $cohort = $DB->get_record('cohort', ['id' => $learningpath->cohortid], 'name', IGNORE_MISSING);
            $cohort_name = $cohort ? $cohort->name : 'Cohorte no encontrada';
            $criterio_texto = 'Pertenecer a la cohorte: ' . $cohort_name;
            break;
        default:
            $criterio_texto = 'Criterio desconocido';
            break;
    }

    // Agregar los datos de la ruta y los cursos a la plantilla
    $template_data['learning_paths'][] = [
        'id' => $learningpath->id,
        'nombre_ruta' => $learningpath->nombre_ruta,
        'url' => $learningpath->url,
        'criterio_texto' => $criterio_texto,
        'editurl' => $editurl->out(),
        'deleteurl' => $deleteurl->out(),
        'cursos' => $cursos // Pasar los cursos asociados
    ];
}

// Renderizar la plantilla
echo $OUTPUT->render_from_template('block_simple_learning_path/simple_learning_path', $template_data);

// Renderizar el pie de página de Moodle
echo $OUTPUT->footer();